const config = {
    getCount: "https://ru12wvs66e.execute-api.us-east-2.amazonaws.com/api/getInstanceCount",
    updateCount: "https://ru12wvs66e.execute-api.us-east-2.amazonaws.com/api/updateInstanceCount"
}

module.exports = config
