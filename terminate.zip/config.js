const config = {
    getCount: "https://ru12wvs66e.execute-api.us-east-2.amazonaws.com/api/getInstanceCount",
    updateInstanceDetails:"https://ru12wvs66e.execute-api.us-east-2.amazonaws.com/api/updateInstanceDetails"
}

module.exports = config
