const config = {
    getCount: "https://ru12wvs66e.execute-api.us-east-2.amazonaws.com/api/getInstanceCount",
    updateStartedInstanceDetails: "https://ru12wvs66e.execute-api.us-east-2.amazonaws.com/api/updateStartedInstanceDetails"
}

module.exports = config
