const config = {
    getCount: "https://ru12wvs66e.execute-api.us-east-2.amazonaws.com/api/getInstanceCount",
    updateStoppedInstanceDetails:"https://ru12wvs66e.execute-api.us-east-2.amazonaws.com/api/updateStoppedInstanceDetails"
}

module.exports = config
